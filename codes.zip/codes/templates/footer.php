 	
 	<footer class="section"> 
 		<div class="center grey-text">Copyright IIIT Ranchi</div>
 	</footer>
 </body>