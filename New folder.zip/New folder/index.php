<?php
	include"connection.php";	
	include"navbar.php";

?>