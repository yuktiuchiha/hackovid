<?php

	$db=mysqli_connect("localhost","root","","hackovid"); 
					/* server name, username, password, database name*/


?>